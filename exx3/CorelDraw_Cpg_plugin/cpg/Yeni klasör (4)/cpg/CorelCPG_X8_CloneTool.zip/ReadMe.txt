# CorelDRAW X8 - 1000 Nesne Kopyalama Aracı

## Derleme Talimatları (MSVC)

1. Visual Studio Developer Command Prompt (x64) aç
2. Klasöre git (örnek: `cd C:\Klasor\CorelCPG_X8_CloneTool`)
3. Derleme komutu:

cl.exe /nologo /utf-8 /w /EHsc /Ox /DNDEBUG /MD app.cpp cpg.cpp /link rpcrt4.lib msvcrt.lib shell32.lib user32.lib gdi32.lib

## Dikkat

- `VGCoreAuto.tlb` dosyası X8 sürümüne uygun olmalı:  
  C:\Program Files\Corel\CorelDRAW Graphics Suite X8\Draw\VGCoreAuto.tlb

- CorelDRAW X8 yüklü ve açık olmalı.

- Nesne seçilmeden çalıştırılırsa hiçbir şey yapmaz.